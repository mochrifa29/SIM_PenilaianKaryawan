
<?php $__env->startSection('content'); ?>
    <div class="page-inner">
        <div class="page-header">
            <h3 class="fw-bold mb-3"><?php echo e($title); ?></h3>

        </div>
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <div class="row">
                            <div class="col-8">
                                <h4>Tanggal : <?php echo e(date('d M Y', strtotime($tanggal))); ?></h4>
                            </div>
                            <div class="col-4">
                                <a href="/penilaian" class="btn btn-warning text-white">Kembali</a>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('manajer')): ?>
                                    <a href="/hitung/<?php echo e($tanggal); ?>" class="btn btn-primary">Hitung Semua</a>
                                <?php endif; ?>

                            </div>
                        </div>


                    </div>
                    <div class="card-body">
                        <?php if(session()->has('success')): ?>
                            <div class="alert alert-success mb-3" role="alert">
                                <?php echo e(session('success')); ?>

                            </div>
                        <?php endif; ?>
                        <div class="table-responsive">
                            <table id="basic-datatables" class="display table table-striped table-hover">
                                <thead>
                                    <tr>
                                        <th>No</th>
                                        <th>Karyawan</th>
                                        <th>Kehadiran</th>
                                        <th>Produksi</th>
                                        <th>Status</th>

                                    </tr>
                                </thead>

                                <tbody>
                                    <?php $__currentLoopData = $penilaian; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($loop->iteration); ?></td>
                                            <td><?php echo e($item->karyawan->nama); ?></td>
                                            <td><?php echo e($item->absensi); ?></td>
                                            <td><?php echo e($item->produksi); ?></td>
                                            <td>
                                                <?php if($item->status == 'Belum dinilai'): ?>
                                                    <span class="badge badge-danger"><?php echo e($item->status); ?></span>
                                                <?php elseif($item->status == 'Sudah dinilai'): ?>
                                                    <span class="badge badge-success"><?php echo e($item->status); ?></span>
                                                <?php endif; ?>
                                            </td>

                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>


        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\project-shendi\resources\views/pages/penilaian/detail.blade.php ENDPATH**/ ?>