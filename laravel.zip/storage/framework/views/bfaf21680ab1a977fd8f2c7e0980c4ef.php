
<?php $__env->startSection('content'); ?>
    <div class="page-inner">
        <div class="page-header">
            <h3 class="fw-bold mb-3"><?php echo e($title); ?></h3>

        </div>
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <div class="row">
                            <div class="col-10">
                                <h4>Tanggal : <?php echo e(date('d M Y', strtotime($tanggal))); ?></h4>
                            </div>
                            <div class="col-2">
                                <a href="/laporan" class="btn btn-warning text-white">Kembali</a>
                            </div>
                        </div>


                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table id="basic-datatables" class="display table table-striped table-hover">
                                <thead>
                                    <tr>
                                        <th>No</th>
                                        <th>Karyawan</th>
                                        <th>Kehadiran</th>
                                        <th>Produksi</th>
                                        <th>Skor</th>
                                        <th>Status</th>

                                    </tr>
                                </thead>

                                <tbody>
                                    <?php $__currentLoopData = $laporan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($loop->iteration); ?></td>
                                            <td><?php echo e($item->penilaian->karyawan->nama); ?></td>
                                            <td><?php echo e($item->penilaian->absensi); ?></td>
                                            <td><?php echo e($item->penilaian->produksi); ?></td>
                                            <td><?php echo e($item->skor); ?></td>
                                            <td>
                                                <?php if($item->status_karyawan == 'Di Perpanjang'): ?>
                                                    <span class="badge badge-success"><?php echo e($item->status_karyawan); ?></span>
                                                <?php endif; ?>
                                                <?php if($item->status_karyawan == 'Tidak Di Perpanjang'): ?>
                                                    <span class="badge badge-danger"><?php echo e($item->status_karyawan); ?></span>
                                                <?php endif; ?>

                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>


        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\project-shendi\resources\views/pages/laporan/detail.blade.php ENDPATH**/ ?>