
<?php $__env->startSection('content'); ?>
    <div class="page-inner">
        <div class="page-header">
            <h3 class="fw-bold mb-3"><?php echo e($title); ?></h3>

        </div>
        <div class="row">
            <div class="col-md-4">
                <div class="card">

                    <div class="card-body">
                        <form action="/tambah-keranjang" method="post">
                            <?php echo csrf_field(); ?>
                            <div class="row">

                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="defaultSelect">Pilih Divisi</label>
                                        <select name="divisi" id="divisi" class="form-select form-control select2">
                                            <option value="">Pilih Divisi</option>
                                            <?php $__currentLoopData = $divisi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($item->divisi); ?>"><?php echo e($item->divisi); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <?php $__errorArgs = ['divisi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <small id="emailHelp2" class="form-text text-danger"><?php echo e($message); ?></small>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                    </div>
                                    <div class="form-group">
                                        <label for="defaultSelect">Pilih Karyawan</label>
                                        <select id="karyawan_id" name="karyawan_id"
                                            class="form-select form-control select2">

                                        </select>
                                        <?php $__errorArgs = ['karyawan_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <small id="emailHelp2" class="form-text text-danger"><?php echo e($message); ?></small>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                    </div>
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label for="email2">Kehadiran</label>
                                                <input type="text" value="<?php echo e(old('absensi')); ?>" class="form-control"
                                                    name="absensi" />
                                                <?php $__errorArgs = ['absensi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <small id="emailHelp2"
                                                        class="form-text text-danger"><?php echo e($message); ?></small>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label for="email2">Jumlah Produksi</label>
                                                <input type="text" class="form-control" name="produksi"
                                                    value="<?php echo e(old('produksi')); ?>" />
                                                <?php $__errorArgs = ['produksi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <small id="emailHelp2"
                                                        class="form-text text-danger"><?php echo e($message); ?></small>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                            </div>
                                        </div>
                                    </div>






                                </div>


                                <br>
                                <div class="form-group">
                                    <button type="submit" class="btn btn-success"><i class="fas fa-plus"></i>
                                        Tambahkan</button>
                                    <a href="/penilaian" class="btn btn-danger">Cancel</a>
                                </div>



                            </div>
                        </form>
                    </div>
                </div>
            </div>
            <div class="col-md-8">

                <div class="card">
                    <div class="card-header">



                        <form action="/penilaian" method="post">
                            <?php echo csrf_field(); ?>
                            <div class="row">
                                <div class="col-8">
                                    <div class="form-group">
                                        <input type="date" class="form-control" name="tanggal_penilaian" />
                                        <?php $__errorArgs = ['tanggal_penilaian'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <small id="emailHelp2" class="form-text text-danger"><?php echo e($message); ?></small>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="col-4">
                                    <button type="submit" class="btn btn-success mt-2">Submit</button>

                                </div>
                            </div>


                        </form>


                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table id="basic-datatables" class="display table table-striped table-hover">
                                <thead>
                                    <tr>
                                        <th>No</th>
                                        <th>Nama</th>
                                        <th>Absensi</th>
                                        <th>Produksi</th>
                                        <th>Divisi</th>
                                        <th>action</th>
                                    </tr>
                                </thead>

                                <tbody>
                                    <?php $__currentLoopData = $keranjang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($loop->iteration); ?></td>

                                            <td><?php echo e($item->karyawan->nama); ?></td>
                                            <td><?php echo e($item->absensi); ?></td>
                                            <td><?php echo e($item->produksi); ?></td>
                                            <td><?php echo e($item->karyawan->divisi); ?></td>
                                            <td>
                                                <form action="/hapusData_keranjang/<?php echo e($item->id); ?>" method="post">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('DELETE'); ?>
                                                    <button type="submit" style="border: none"
                                                        onclick="return confirm('Apakah anda yakin ingin menghapusnya?')"><i
                                                            class="fa fa-trash text-danger"></i></button>
                                                </form>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </tbody>
                            </table>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>
    <script>
        $(document).ready(function() {
            $("#divisi").change(function() {
                divisi = $(this).val();

                let token = $("meta[name='csrf-token']").attr("content")
                $.ajax({
                    type: "GET",
                    url: "/cek_karyawan/" + divisi,
                    data: {
                        "_token": token
                    },
                    success: function(response) {

                        baris = "";
                        for (let i = 0; i < response.length; i++) {
                            const element = response[i];
                            baris += '<option value="' + element.id + '">' + element
                                .nama +
                                '</option>';
                        }
                        $("#karyawan_id").html(baris);
                    }
                })
            })
        })
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\project-shendi\resources\views/pages/penilaian/form_tambah.blade.php ENDPATH**/ ?>