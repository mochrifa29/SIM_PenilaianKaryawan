<footer class="footer">
    <div class="container-fluid d-flex justify-content-between">
        <div class="copyright">

        </div>
    </div>
</footer>
<?php /**PATH C:\laragon\www\project-shendi\resources\views/partials/footer.blade.php ENDPATH**/ ?>