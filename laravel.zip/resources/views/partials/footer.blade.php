<footer class="footer">
    <div class="container-fluid d-flex justify-content-between">
        <div class="copyright">

        </div>
    </div>
</footer>
